window.alert = function() {};
// General Behavior

$('body').append('<div id="FilterDiv"></div>');
//$("#FilterDiv").load('filterModals.html');
$("#sidebar-wrapper").load('navigation.html'); // Load nav into #sidebar-wrapper
//$('div.pageTitle h1').append('  <a href="#"><i class="fa fa-caret-square-o-down" style="cursor:pointer;font-size:0.9em;padding:5px;" data-toggle="modal" data-target="#FilterModal"></i></a> ');


/*global require, alert*/
/*
 *
 * @owner Enter you name here (xxx)
 */
/*
 *    Fill in host and port for Qlik engine
 */
var prefix = window.location.pathname.substr( 0, window.location.pathname.toLowerCase().lastIndexOf( "/extensions" ) + 1 );
var config = {
	host: window.location.hostname,
	prefix: prefix,
	port: window.location.port,
	isSecure: window.location.protocol === "https:"
};
require.config( {
	baseUrl: ( config.isSecure ? "https://" : "http://" ) + config.host + (config.port ? ":" + config.port: "") + config.prefix + "resources"
} );

require( ["js/qlik"], function ( qlik ) {
	qlik.setOnError( function ( error ) {
		alert( error.message );
	} );

	//callbacks -- inserted here --


	//open apps -- inserted here --
	//var app = qlik.openApp('368ce8a9-a90a-4fa8-899c-e1300a64c5e8', config);
	var app = qlik.openApp('Qlik Race Game.qvf', config);


    setInterval(reload(), 10000);

    function reload(){
        app.doReload().then(function(){
		   app.doSave();
		   console.log('App Reloaded...');
		});
    };


	//get objects -- inserted here --
	app.getObject('CurrentSelections','CurrentSelections');

	// Filters
	//app.getObject('LB_Year','ganxtky');
	//app.getObject('LB_Store','XbTFc');
	//app.getObject('LB_Country','sxppfc');

	// My Spotify
	app.getObject('TotalLaps','uhjmS');
	app.getObject('FastestLap','TDmGjuF');
	app.getObject('SlowestLap','jZvaG');
	app.getObject('AvgLapTime','CKjtXmb');

	app.getObject('LapTimeDistribution','QmEgUY');
	app.getObject('SessionHeatmap','LPEGfjP');

	app.getObject('RaceSim','BVAt');

	app.getObject('LeaderLaps','sjhFPWz');
	app.getObject('LeaderSessions','WqdJm');
	app.getObject('LeaderMostLaps','BEZmjr');

	app.getObject('LB_Player','TpVXjt');
	app.getObject('LB_Lap','wYQepvm');


	$('a').on('click', function(event) {
		qlik.resize();
		$('.modal-body').hide().toggleResize();
	});

	// Access Variables

	// Trigger Events
  // Function to toggle hidden objects in a bootstrap popup modal
	$.fn.extend({
	  toggleResize: function() {
	    return this.toggle(400, function() {
	      qlik.resize();
	    });
	  }
	});

	// IDs for showing up on toggleResize function (see above)
	$('#ShowMap').on('click', function(event) {
     $('#LB_ProductCategory2').hide().toggleResize();
		 $('#CustomerGeography').hide().toggleResize();
		 $('#LB_MaritalStatus').hide().toggleResize();
		 $('#SalesOverTime').hide().toggleResize();
	 });

	 $('#showViz').on('click', function(event) {
 		 qlik.resize();
		 $('#SalesOverTime').hide().toggleResize();
 	 });

	 $('.fa-chevron-up').on('click', function(event) {
     $('#SalesOverTime').hide().toggleResize();
 	 });

		// Initiate all ToolTips on a page
		$(function () {
		  $('[data-toggle="tooltip"]').tooltip()
		})

		// Initiate all Popovers on a page
		$(function () {
		  $('[data-toggle="popover"]').popover()
		})

		// Show / Hide content based on Qlik Variable
		app.getList("SelectionObject", function(reply) { // First check if there are changes in a selection
				app.variable.getContent("vCountCustomers", function (reply) { // Then get the value of a variable
				   Test2 = Number(reply.qContent.qString);
					 console.log(Test2);
					 qlik.resize();
					 // app.getList("SelectionObject", function(reply) {    }

					 			if(Test2 == 1) {
					 					$('#CustomerDiv').show();
										$('#CustomerDiv2').show();
					 			}
					 			else if(Test2 != 1)
					 			{
					 					$('#CustomerDiv').hide();
										$('#CustomerDiv2').hide();
					 			}
					});
		});

		// Clear All selections
	$("#ClearAll").click(function() {
    	app.clearAll();
  	});

  	$("#Reload").click(function() {
    	app.doReload().then(function(){
		   app.doSave();
		});
  	});


	//create cubes and lists -- inserted here --


} );
