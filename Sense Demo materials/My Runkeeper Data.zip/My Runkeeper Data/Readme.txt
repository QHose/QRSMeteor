Your Runkeeper Dashboard installer has installed some files to c:\TEMP\

The data that this dashboard needs to load needs to go into c:\TEMP\My Runkeeper Data\

To get up and running with the Runkeeper Dashboard you need to do the following:

1.	Download your data from runkeeper.com
2.	Unpack the zipfile in c:\TEMP\My Runkeeper Data\
3.  Make sure that the data files are in the root of this folder (All files - *.txt / *.gpx should be in c:\TEMP\My Runkeeper Data\)
4.	Open Qlik Sense
5.	Open the Runkeeper Dashboard app
6.	Go to the data load editor
7.	Click on 'load data'
8.	Go to the app overview and choose 'Dashboard'

After this you will be looking at your own data.

Have fun analyzing it.

Note: To uninstall the dashboard just use the uninstaller program which can be found under c:\TEMP\Uninstall My Twitter Dashboard.exe