const ATTRIBUTES = {
  overridedLabel: {
    ref: "qAttributeExpressions.0.qExpression",
    index: 0
  }
};

export default ATTRIBUTES;
